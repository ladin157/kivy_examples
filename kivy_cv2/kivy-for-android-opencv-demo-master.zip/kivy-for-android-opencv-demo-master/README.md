参考国外网友的例子，新鲜出炉的demo，适用于在安卓手机操作摄像头每一帧的场景，比如人脸识别，运动检测等。

在qpython1.4.1运行通过，kivy打包也是没问题的。

修改main.py里面的detect函数就可以操作当前帧的画面了。

就这么任性。

下面是必应翻译给外国友人看的

Refer to the example of foreign netizens, fresh out of the demo, for the Android phone operating camera every frame of the scene, such as face recognition, motion detection.

Running through the qpython1.4.1, Kivy packaging is no problem.

Modify the main.py inside the detect function to manipulate the current frame of the screen. 

So willful.
